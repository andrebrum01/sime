import React,{Component} from "react";

import {Container} from './styled';

export default class Navbar extends Component{
 render(){
    return(
    <Container>
       <div/>
       <ul>
          <li>Learn</li>
          <li>Motores</li>
          <li>Download</li>
       </ul>
    </Container>
    );
 }

}